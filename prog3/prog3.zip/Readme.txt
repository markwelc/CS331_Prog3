Group Members:

Cameron Markwell
Pavel Shonka

Input Files
Input training file should be named 	: trainingSet
Input test file should be named 		: testSet

Output Files
Output training file should be named 	: preprocessed_train
Output test file should be named 		: preprocessed_test

this program is written in c++
compiled as:
	g++ prog3Main.cpp -o prog3Main
	
Should compile on the school servers but will for sure compile with MinGW on windows
